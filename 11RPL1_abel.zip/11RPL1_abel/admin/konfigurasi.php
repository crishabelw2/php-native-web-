<?php
include '../config.php';

if (isset($_POST['simpan'])) {
    $judul = $_POST['judul'];
    $subjudul = $_POST['subjudul'];
    $status = $_POST['status'];
    $namagambar = $_FILES['gambar']['name'];
    $ekstensi_diperbolehkan = array('png', 'jpg', 'jpeg');
    $x = explode('.', $namagambar);
    $ekstensi = strtolower(end($x));
    $ukuran = $_FILES['gambar']['size'];
    $file_tmp = $_FILES['gambar']['tmp_name'];

    if (in_array($ekstensi, $ekstensi_diperbolehkan) && $ukuran < 1048576) {
        move_uploaded_file($file_tmp, '../assets/img/' . $namagambar);
        // Gunakan parameterized query untuk menghindari SQL Injection
        $stmt = $koneksi->prepare("INSERT INTO hero (gambar, judul, subjudul, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $namagambar, $judul, $subjudul, $status);
        $stmt->execute();
        $stmt->close();

        header("location:index.php");
    } else {
        $_SESSION['gagalposting'] = "Maaf Postingan tidak berhasil disimpan karena Format tidak sesuai atau ukuran terlalu besar";
        header("location:index.php?gagal");
    }
}

if (isset($_GET['delete'])) {
    $idHero = $_GET['delete'];
    // Gunakan parameterized query untuk menghindari SQL Injection
    $stmt = $koneksi->prepare("DELETE FROM hero WHERE idHero = ?");
    $stmt->bind_param("i", $idHero);
    $stmt->execute();
    $stmt->close();

    header("location:index.php");
}

if (isset($_POST['editposting'])) {
    $judul = $_POST['judul'];
    $subjudul = $_POST['subjudul'];
    $status = $_POST['status'];
    $namagambar = $_FILES['gambar']['name'];
    $file_tmp = $_FILES['gambar']['tmp_name'];
    move_uploaded_file($file_tmp, '../assets/img/' . $namagambar);

    // Gunakan parameterized query untuk menghindari SQL Injection
    $stmt = $koneksi->prepare("UPDATE hero SET judul=?, subjudul=?, gambar=?, status=? WHERE judul=?");
    $stmt->bind_param("sssss", $judul, $subjudul, $namagambar, $status, $judul);
    $stmt->execute();
    $stmt->close();

    header("location:index.php");
}
?>